
import Image from "next/image";
import "../styles/BannerAnimation.scss";

export default function AboutAnimation() {

  return (
    <>
    
    <div className="banner-animation">

  <div className="orbit orbit-1"></div>
  <div className="orbit orbit-2"></div>
  <div className="orbit orbit-3"></div>

  <div className="center-orb">
    <Image
      src="/Component 36.png"
      alt=""
      width={350}
      height={350}
    />
  </div>

  <div className="icon innovation">
      <Image src="/innovation.png" width={70} height={70} alt="" />
      <span>Innovation</span>
  </div>

  <div className="icon growth">
      <Image src="/excel.png" width={70} height={70} alt="" />
      <span>Growth</span>
  </div>

  <div className="icon security">
      <Image src="/integrity.png" width={70} height={70} alt="" />
      <span>Security</span>
  </div>

  <div className="icon collaboration">
      <Image src="/collab.png" width={70} height={70} alt="" />
      <span>Collaboration</span>
  </div>

</div>
    </>
  );
}